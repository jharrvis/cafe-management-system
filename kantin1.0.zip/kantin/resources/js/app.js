import './bootstrap';
import 'jquery';
import '@fortawesome/fontawesome-free/js/all.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
