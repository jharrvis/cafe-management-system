<x-app-layout>
    <div class="py-6">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="mb-6">
                <a href="{{ route('admin.orders.index') }}" class="text-blue-600 hover:text-blue-800 mb-4 inline-block">
                    <i class="fas fa-arrow-left mr-2"></i>Kembali ke Daftar Pesanan
                </a>
                <div class="flex justify-between items-start">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Detail Pesanan</h1>
                        <p class="text-sm text-gray-600 mt-1">{{ $order->order_number }}</p>
                    </div>
                    <span class="px-4 py-2 inline-flex text-sm font-semibold rounded-full
                        {{ $order->status == 'menunggu' ? 'bg-yellow-100 text-yellow-800' : '' }}
                        {{ $order->status == 'diproses' ? 'bg-blue-100 text-blue-800' : '' }}
                        {{ $order->status == 'siap_diambil' ? 'bg-green-100 text-green-800' : '' }}
                        {{ $order->status == 'selesai' ? 'bg-gray-100 text-gray-800' : '' }}">
                        {{
                            $order->status == 'menunggu' ? 'Menunggu' :
                            ($order->status == 'diproses' ? 'Diproses' :
                            ($order->status == 'siap_diambil' ? 'Siap Diambil' : 'Selesai'))
                        }}
                    </span>
                </div>
            </div>

            <!-- Success Message -->
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    {{ session('success') }}
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Order Info -->
                <div class="md:col-span-2 space-y-6">
                    <!-- Customer Information -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Informasi Pelanggan</h2>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Nama:</span>
                                <span class="text-sm font-medium text-gray-900">{{ $order->user->name }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Email:</span>
                                <span class="text-sm font-medium text-gray-900">{{ $order->user->email }}</span>
                            </div>
                            @if($order->user->nisn)
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">NISN:</span>
                                <span class="text-sm font-medium text-gray-900">{{ $order->user->nisn }}</span>
                            </div>
                            @endif
                        </div>
                    </div>

                    <!-- Order Items -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Item Pesanan</h2>
                        <div class="space-y-4">
                            @foreach($order->orderItems as $item)
                                <div class="flex items-center space-x-4 pb-4 border-b border-gray-200 last:border-0 last:pb-0">
                                    @if($item->product->image)
                                        <img src="{{ asset($item->product->image) }}" alt="{{ $item->product->name }}" class="w-16 h-16 object-cover rounded">
                                    @else
                                        <div class="w-16 h-16 bg-gray-200 rounded flex items-center justify-center">
                                            <i class="fas fa-image text-gray-400"></i>
                                        </div>
                                    @endif
                                    <div class="flex-1">
                                        <h3 class="text-sm font-medium text-gray-900">{{ $item->product->name }}</h3>
                                        <p class="text-xs text-gray-500 mt-1">{{ $item->product->category->name }}</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-medium text-gray-900">{{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                                        <p class="text-sm font-bold text-blue-600 mt-1">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</p>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <!-- Total -->
                        <div class="mt-6 pt-4 border-t-2 border-gray-200">
                            <div class="flex justify-between items-center">
                                <span class="text-lg font-semibold text-gray-900">Total Pembayaran</span>
                                <span class="text-2xl font-bold text-blue-600">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Actions -->
                <div class="space-y-6">
                    <!-- Order Timeline -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Timeline Pesanan</h2>
                        <div class="space-y-3">
                            <div class="flex items-start">
                                <div class="flex items-center justify-center w-8 h-8 rounded-full {{ $order->status == 'menunggu' ? 'bg-yellow-100' : 'bg-green-100' }} flex-shrink-0">
                                    <i class="fas fa-clock text-xs {{ $order->status == 'menunggu' ? 'text-yellow-600' : 'text-green-600' }}"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-medium text-gray-900">Pesanan Dibuat</p>
                                    <p class="text-xs text-gray-500">{{ $order->created_at->format('d M Y, H:i') }}</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center justify-center w-8 h-8 rounded-full {{ in_array($order->status, ['diproses', 'siap_diambil', 'selesai']) ? 'bg-green-100' : 'bg-gray-100' }} flex-shrink-0">
                                    <i class="fas fa-spinner text-xs {{ in_array($order->status, ['diproses', 'siap_diambil', 'selesai']) ? 'text-green-600' : 'text-gray-400' }}"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-medium text-gray-900">Diproses</p>
                                    <p class="text-xs text-gray-500">{{ in_array($order->status, ['diproses', 'siap_diambil', 'selesai']) ? 'Sedang diproses' : 'Menunggu' }}</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center justify-center w-8 h-8 rounded-full {{ in_array($order->status, ['siap_diambil', 'selesai']) ? 'bg-green-100' : 'bg-gray-100' }} flex-shrink-0">
                                    <i class="fas fa-check text-xs {{ in_array($order->status, ['siap_diambil', 'selesai']) ? 'text-green-600' : 'text-gray-400' }}"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-medium text-gray-900">Siap Diambil</p>
                                    <p class="text-xs text-gray-500">{{ in_array($order->status, ['siap_diambil', 'selesai']) ? 'Pesanan siap' : 'Menunggu' }}</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center justify-center w-8 h-8 rounded-full {{ $order->status == 'selesai' ? 'bg-green-100' : 'bg-gray-100' }} flex-shrink-0">
                                    <i class="fas fa-check-double text-xs {{ $order->status == 'selesai' ? 'text-green-600' : 'text-gray-400' }}"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-medium text-gray-900">Selesai</p>
                                    <p class="text-xs text-gray-500">
                                        {{ $order->status == 'selesai' ? $order->completed_at?->format('d M Y, H:i') : 'Menunggu' }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Update Status -->
                    @if($order->status != 'selesai')
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Update Status</h2>
                        <form action="{{ route('admin.orders.updateStatus', $order->id) }}" method="POST">
                            @csrf
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Status Baru</label>
                                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required>
                                        <option value="menunggu" {{ $order->status == 'menunggu' ? 'selected' : '' }}>Menunggu</option>
                                        <option value="diproses" {{ $order->status == 'diproses' ? 'selected' : '' }}>Diproses</option>
                                        <option value="siap_diambil" {{ $order->status == 'siap_diambil' ? 'selected' : '' }}>Siap Diambil</option>
                                        <option value="selesai" {{ $order->status == 'selesai' ? 'selected' : '' }}>Selesai</option>
                                    </select>
                                </div>
                                <button type="submit" class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                                    <i class="fas fa-save mr-2"></i>Update Status
                                </button>
                            </div>
                        </form>
                    </div>
                    @endif

                    <!-- Order Info Card -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Informasi Pesanan</h2>
                        <div class="space-y-3">
                            <div>
                                <span class="text-xs text-gray-600">No. Pesanan</span>
                                <p class="text-sm font-medium text-gray-900">{{ $order->order_number }}</p>
                            </div>
                            <div>
                                <span class="text-xs text-gray-600">Metode Pembayaran</span>
                                <p class="text-sm font-medium text-gray-900">{{ ucfirst($order->payment_method) }}</p>
                            </div>
                            <div>
                                <span class="text-xs text-gray-600">Total Item</span>
                                <p class="text-sm font-medium text-gray-900">{{ $order->orderItems->sum('quantity') }} item</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
