<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-6">
                <h1 class="text-xl sm:text-2xl font-bold text-gray-900">Manajemen Produk</h1>
                <a href="<?php echo e(route('admin.products.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition text-center text-sm sm:text-base">
                    <i class="fas fa-plus mr-2"></i>Tambah Produk
                </a>
            </div>

            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                <div class="bg-white rounded-lg shadow p-3">
                    <div class="flex items-center">
                        <div class="p-2 rounded-full bg-blue-100 text-blue-600">
                            <i class="fas fa-box text-base"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-xs text-gray-500">Total</p>
                            <p class="text-lg font-bold text-gray-900"><?php echo e($products->total()); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-3">
                    <div class="flex items-center">
                        <div class="p-2 rounded-full bg-green-100 text-green-600">
                            <i class="fas fa-check-circle text-base"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-xs text-gray-500">Tersedia</p>
                            <p class="text-lg font-bold text-gray-900"><?php echo e($products->where('is_available', true)->count()); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-3">
                    <div class="flex items-center">
                        <div class="p-2 rounded-full bg-red-100 text-red-600">
                            <i class="fas fa-exclamation-circle text-base"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-xs text-gray-500">Stok <</p>
                            <p class="text-lg font-bold text-gray-900"><?php echo e($products->where('stock', '<=', 10)->count()); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-3">
                    <div class="flex items-center">
                        <div class="p-2 rounded-full bg-yellow-100 text-yellow-600">
                            <i class="fas fa-tags text-base"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-xs text-gray-500">Kategori</p>
                            <p class="text-lg font-bold text-gray-900"><?php echo e($categories->count()); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Products List - Mobile Friendly -->
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <div class="flex p-3">
                            <!-- Product Image -->
                            <div class="flex-shrink-0">
                                <?php if($product->image): ?>
                                    <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-20 h-20 object-cover rounded-lg">
                                <?php else: ?>
                                    <div class="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-image text-gray-400"></i>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Product Info -->
                            <div class="ml-3 flex-1 min-w-0">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1 min-w-0">
                                        <h3 class="text-sm font-semibold text-gray-900 truncate"><?php echo e($product->name); ?></h3>
                                        <p class="text-xs text-gray-500 mt-0.5 truncate"><?php echo e($product->description); ?></p>
                                    </div>

                                    <!-- Action Buttons -->
                                    <div class="flex items-center space-x-2 ml-2">
                                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>"
                                           class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition">
                                            <i class="fas fa-edit text-sm"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
                                              method="POST"
                                              onsubmit="return confirm('Yakin ingin menghapus produk ini?')"
                                              class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition">
                                                <i class="fas fa-trash text-sm"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>

                                <!-- Product Details -->
                                <div class="mt-2 flex flex-wrap items-center gap-2 text-xs">
                                    <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full font-medium">
                                        <?php echo e($product->category->name); ?>

                                    </span>
                                    <span class="px-2 py-1 rounded-full font-semibold
                                        <?php echo e($product->stock > 10 ? 'bg-green-100 text-green-800' : ($product->stock > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800')); ?>">
                                        Stok: <?php echo e($product->stock); ?>

                                    </span>
                                    <form action="<?php echo e(route('admin.products.toggle', $product->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="px-2 py-1 rounded-full font-semibold
                                            <?php echo e($product->is_available ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-red-100 text-red-800 hover:bg-red-200'); ?>">
                                            <?php echo e($product->is_available ? 'Tersedia' : 'Tidak Tersedia'); ?>

                                        </button>
                                    </form>
                                </div>

                                <!-- Price -->
                                <div class="mt-2">
                                    <span class="text-sm font-bold text-blue-600">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="bg-white rounded-lg shadow-md p-8 text-center">
                        <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-box text-2xl text-gray-400"></i>
                        </div>
                        <p class="text-gray-500">Belum ada produk.</p>
                        <a href="<?php echo e(route('admin.products.create')); ?>" class="text-blue-600 hover:underline text-sm">Tambah produk pertama</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if($products->hasPages()): ?>
                <div class="mt-4">
                    <?php echo e($products->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\kantin\resources\views/admin/products/index.blade.php ENDPATH**/ ?>