# Daftar Pengguna Aplikasi Kantin Sekolah

## Admin Account
- **Email**: admin@kantin.sch.id
- **NISN**: (null)
- **Password**: password
- **Role**: admin

## Student Accounts
1. **Name**: Budi Santoso
   - **Email**: budi@kantin.sch.id
   - **NISN**: 1234567890
   - **Password**: password
   - **Role**: student

2. **Name**: Ani Lestari
   - **Email**: ani@kantin.sch.id
   - **NISN**: 0987654321
   - **Password**: password
   - **Role**: student

3. **Name**: Siti Nurhaliza
   - **Email**: siti@kantin.sch.id
   - **NISN**: 1122334455
   - **Password**: password
   - **Role**: student

4. **Name**: Ahmad Fauzi
   - **Email**: ahmad@kantin.sch.id
   - **NISN**: 5544332211
   - **Password**: password
   - **Role**: student

5. **Name**: Dewi Kartika
   - **Email**: dewi@kantin.sch.id
   - **NISN**: 6677889900
   - **Password**: password
   - **Role**: student

## Catatan
- Semua akun menggunakan password yang sama: "password"
- Sistem mendukung login menggunakan email atau NISN (khusus untuk siswa)
- Admin memiliki akses ke dashboard admin
- Siswa memiliki akses ke dashboard siswa